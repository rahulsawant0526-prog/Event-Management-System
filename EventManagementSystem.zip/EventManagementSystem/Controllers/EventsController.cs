using Microsoft.AspNetCore.Mvc;
using EventManagementSystem.Models;

namespace EventManagementSystem.Controllers
{
    public class EventsController : Controller
    {
        private static List<Event> _events = new()
        {
            new Event { Id = 1, Title = "Tech Conference", Description = "A full-day tech event", Date = DateTime.Today.AddDays(10), Location = "New York" },
            new Event { Id = 2, Title = "Music Festival", Description = "Outdoor concert and fun", Date = DateTime.Today.AddDays(30), Location = "Los Angeles" }
        };

        public IActionResult Index() => View(_events);

        public IActionResult Details(int id)
        {
            var ev = _events.FirstOrDefault(e => e.Id == id);
            if (ev == null) return NotFound();
            return View(ev);
        }

        public IActionResult Create() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Event ev)
        {
            if (ModelState.IsValid)
            {
                ev.Id = _events.Count > 0 ? _events.Max(e => e.Id) + 1 : 1;
                _events.Add(ev);
                return RedirectToAction(nameof(Index));
            }
            return View(ev);
        }

        public IActionResult Edit(int id)
        {
            var ev = _events.FirstOrDefault(e => e.Id == id);
            if (ev == null) return NotFound();
            return View(ev);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Event updated)
        {
            if (id != updated.Id) return NotFound();
            if (ModelState.IsValid)
            {
                var ev = _events.FirstOrDefault(e => e.Id == id);
                if (ev == null) return NotFound();

                ev.Title = updated.Title;
                ev.Description = updated.Description;
                ev.Date = updated.Date;
                ev.Location = updated.Location;

                return RedirectToAction(nameof(Index));
            }
            return View(updated);
        }

        public IActionResult Delete(int id)
        {
            var ev = _events.FirstOrDefault(e => e.Id == id);
            if (ev == null) return NotFound();
            return View(ev);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var ev = _events.FirstOrDefault(e => e.Id == id);
            if (ev != null) _events.Remove(ev);
            return RedirectToAction(nameof(Index));
        }
    }
}
